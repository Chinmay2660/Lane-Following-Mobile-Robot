# Read-and-Write-Bitmap-Image-using-C-programming-
Here I have given a program to read and write a Bitmap Image using C programming language
